load PFC_Area.mat

%[H,P] = ttest2;
%[H,P,CI,STATS] = ttest2;

PFC_Area_FemC = [PFC_Area_13;PFC_Area_14];
PFC_Area_FemP = [PFC_Area_10;PFC_Area_12];
PFC_Area_MaleC = [PFC_Area_7;PFC_Area_8];
PFC_Area_MaleP = [PFC_Area_9;PFC_Area_11];

%Count number of microglia per subject
N_7_PFC = nnz(~isnan(PFC_Area_7));
N_8_PFC = nnz(~isnan(PFC_Area_8));
N_9_PFC = nnz(~isnan(PFC_Area_9));
N_10_PFC = nnz(~isnan(PFC_Area_10));
N_11_PFC = nnz(~isnan(PFC_Area_11));
N_12_PFC = nnz(~isnan(PFC_Area_12));
N_13_PFC = nnz(~isnan(PFC_Area_13));
N_14_PFC = nnz(~isnan(PFC_Area_14));

%Count number of microglia per group
N_MaleC_PFC = N_7_PFC + N_8_PFC;
N_MaleP_PFC = N_9_PFC + N_11_PFC;
N_FemC_PFC = N_13_PFC + N_14_PFC;
N_FemP_PFC = N_10_PFC + N_12_PFC;

Mean_MaleC_PFC = mean(PFC_Area_MaleC,'omitnan');
Mean_FemC_PFC = mean(PFC_Area_FemC,'omitnan');
Std_MaleC_PFC = std(PFC_Area_MaleC,'omitnan');
Std_FemC_PFC = std(PFC_Area_FemC,'omitnan');
Mean_MaleP_PFC = mean(PFC_Area_MaleP,'omitnan');
Mean_FemP_PFC = mean(PFC_Area_FemP,'omitnan');
Std_MaleP_PFC = std(PFC_Area_MaleP,'omitnan');
Std_FemP_PFC = std(PFC_Area_FemP,'omitnan');

%Test baseline sex differences
[H,P,CI,STATS] = ttest2(PFC_Area_MaleC,PFC_Area_FemC,'vartype','unequal')
meanEffectSize(PFC_Area_MaleC,PFC_Area_FemC,Effect="cohen",VarianceType="unequal")

%Test whether male control is different from male paired
[H,P,CI,STATS] = ttest2(PFC_Area_MaleC,PFC_Area_MaleP,'vartype','unequal')
meanEffectSize(PFC_Area_MaleC,PFC_Area_MaleP,Effect="cohen",VarianceType="unequal")

%Test whether female control is different from female paired
[H,P,CI,STATS] = ttest2(PFC_Area_FemC,PFC_Area_FemP,'vartype','unequal')
meanEffectSize(PFC_Area_FemC,PFC_Area_FemP,Effect="cohen",VarianceType="unequal")

%Test whether male paired is different from female paired
[H,P,CI,STATS] = ttest2(PFC_Area_MaleP,PFC_Area_FemP,'vartype','unequal')
meanEffectSize(PFC_Area_MaleP,PFC_Area_FemP,Effect="cohen",VarianceType="unequal")

%Test whether paired are different from unpaired
PFC_Area_AllC = [PFC_Area_7;PFC_Area_8;PFC_Area_13;PFC_Area_14];
PFC_Area_AllP = [PFC_Area_9;PFC_Area_10;PFC_Area_11;PFC_Area_12];
N_AllC_PFC = N_7_PFC+N_8_PFC+N_13_PFC+N_14_PFC;
N_AllP_PFC = N_9_PFC+N_10_PFC+N_11_PFC+N_12_PFC;
Mean_AllC_PFC = mean(PFC_Area_AllC,'omitnan');
Mean_AllP_PFC = mean(PFC_Area_AllP,'omitnan');
Std_AllC_PFC = std(PFC_Area_AllC,'omitnan');
Std_AllP_PFC = std(PFC_Area_AllP,'omitnan');
[H,P,CI,STATS] = ttest2(PFC_Area_AllC,PFC_Area_AllP,'vartype','unequal')
meanEffectSize(PFC_Area_AllC,PFC_Area_AllP,Effect="cohen",VarianceType="unequal")