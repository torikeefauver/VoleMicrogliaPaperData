load ACC_Area.mat
load PFC_Area.mat

%[H,P] = ttest2;
%[H,P,CI,STATS] = ttest2;

Area_7 = [ACC_Area_7;PFC_Area_7];
Area_8 = [ACC_Area_8;PFC_Area_8];
Area_9 = [ACC_Area_9;PFC_Area_9];
Area_10 = [ACC_Area_10;PFC_Area_10];
Area_11 = [ACC_Area_11;PFC_Area_11];
Area_12 = [ACC_Area_12;PFC_Area_12];
Area_13 = [ACC_Area_13;PFC_Area_13];
Area_14 = [ACC_Area_14;PFC_Area_14];

Area_FemC = [ACC_Area_13;ACC_Area_14;PFC_Area_13;PFC_Area_14];
Area_FemP = [ACC_Area_10;ACC_Area_12;PFC_Area_10;PFC_Area_12];
Area_MaleC = [ACC_Area_7;ACC_Area_8;PFC_Area_7;PFC_Area_8];
Area_MaleP = [ACC_Area_9;ACC_Area_11;PFC_Area_9;PFC_Area_11];

%Count number of microglia per subject
N_7 = nnz(~isnan(Area_7));
N_8 = nnz(~isnan(Area_8));
N_9 = nnz(~isnan(Area_9));
N_10 = nnz(~isnan(Area_10));
N_11 = nnz(~isnan(Area_11));
N_12 = nnz(~isnan(Area_12));
N_13 = nnz(~isnan(Area_13));
N_14 = nnz(~isnan(Area_14));

%Count number of microglia per group
N_MaleC = N_7 + N_8;
N_MaleP = N_9 + N_11;
N_FemC = N_13 + N_14;
N_FemP = N_10 + N_12;

Mean_MaleC = mean(Area_MaleC,'omitnan');
Mean_FemC = mean(Area_FemC,'omitnan');
Std_MaleC = std(Area_MaleC,'omitnan');
Std_FemC = std(Area_FemC,'omitnan');
Mean_MaleP = mean(Area_MaleP,'omitnan');
Mean_FemP = mean(Area_FemP,'omitnan');
Std_MaleP = std(Area_MaleP,'omitnan');
Std_FemP = std(Area_FemP,'omitnan');

%Test baseline sex differences
[H,P,CI,STATS] = ttest2(Area_MaleC,Area_FemC,'vartype','unequal')
meanEffectSize(Area_MaleC,Area_FemC,Effect="cohen",VarianceType="unequal")

%Test whether male control is different from male paired
[H,P,CI,STATS] = ttest2(Area_MaleC,Area_MaleP,'vartype','unequal')
meanEffectSize(Area_MaleC,Area_MaleP,Effect="cohen",VarianceType="unequal")

%Test whether female control is different from female paired
[H,P,CI,STATS] = ttest2(Area_FemC,Area_FemP,'vartype','unequal')
meanEffectSize(Area_FemC,Area_FemP,Effect="cohen",VarianceType="unequal")

%Test whether male paired is different from female paired
[H,P,CI,STATS] = ttest2(Area_MaleP,Area_FemP,'vartype','unequal')
meanEffectSize(Area_MaleP,Area_FemP,Effect="cohen",VarianceType="unequal")

%Test whether paired are different from unpaired
Area_AllC = [Area_7;Area_8;Area_13;Area_14];
Area_AllP = [Area_9;Area_10;Area_11;Area_12];
N_AllC = N_7+N_8+N_13+N_14;
N_AllP = N_9+N_10+N_11+N_12;
Mean_AllC = mean(Area_AllC,'omitnan');
Mean_AllP = mean(Area_AllP,'omitnan');
Std_AllC = std(Area_AllC,'omitnan');
Std_AllP = std(Area_AllP,'omitnan');
[H,P,CI,STATS] = ttest2(Area_AllC,Area_AllP,'vartype','unequal')
meanEffectSize(Area_AllC,Area_AllP,Effect="cohen",VarianceType="unequal")


%3 way anova
Matrix = [ACC_Area_7;ACC_Area_8;ACC_Area_9;ACC_Area_10;ACC_Area_11;ACC_Area_12;ACC_Area_13;ACC_Area_14;PFC_Area_7;PFC_Area_8;PFC_Area_9;PFC_Area_10;PFC_Area_11;PFC_Area_12;PFC_Area_13;PFC_Area_14];
Matrix_trans = 1./Matrix;

%group 1 is sex
g_1 = [Male;Male;Male;Female;Male;Female;Female;Female;Male2;Male2;Male2;Female2;Male2;Female2;Female2;Female2]

%group 2 is pairing
g_2 = [UnPaired;UnPaired;Paired;Paired;Paired;Paired;UnPaired;UnPaired;UnPaired2;UnPaired2;Paired2;Paired2;Paired2;Paired2;UnPaired2;UnPaired2]

%group 3 is brain region
g3 = [ACC;ACC;ACC;ACC;ACC;ACC;ACC;ACC;PFC;PFC;PFC;PFC;PFC;PFC;PFC;PFC]

Female2 = ones(950,1)
Male2 = zeros(950,1)

[P,T,STATS] = anovan(Matrix_trans,{g_1,g_2,g3},'model','interaction')

%totalSS = 271794144.5;
%eta_squared1 = 1017000.6/totalSS
%eta_squared2 = 8307.3/totalSS
%eta_squared3 = 26402.3/totalSS

%2-way within males
Area_M = [ACC_Area_7;ACC_Area_8;ACC_Area_9;ACC_Area_11;PFC_Area_7;PFC_Area_8;PFC_Area_9;PFC_Area_11]

g7 = [UnPaired;UnPaired;Paired;Paired;UnPaired2;UnPaired2;Paired2;Paired2]
g8 = [ACC;ACC;ACC;ACC;PFC;PFC;PFC;PFC]

[P,T,STATS] = anovan(Area_M,{g7,g8},'model','interaction')

%2-way within females
Area_F = [ACC_Area_10;ACC_Area_12;ACC_Area_13;ACC_Area_14;PFC_Area_10;PFC_Area_12;PFC_Area_13;PFC_Area_14]

g11 = [Paired;Paired;UnPaired;UnPaired;Paired2;Paired2;UnPaired2;UnPaired2]
g12 = [ACC;ACC;ACC;ACC;PFC;PFC;PFC;PFC]

[P,T,STATS] = anovan(Area_F,{g11,g12},'model','interaction')
