
load ACC_Area.mat

%[H,P] = ttest2;
%[H,P,CI,STATS] = ttest2;

ACC_Area_FemC = [ACC_Area_13;ACC_Area_14];
ACC_Area_FemP = [ACC_Area_10;ACC_Area_12];
ACC_Area_MaleC = [ACC_Area_7;ACC_Area_8];
ACC_Area_MaleP = [ACC_Area_9;ACC_Area_11];

%Count number of microglia per subject
N_7_ACC = nnz(~isnan(ACC_Area_7));
N_8_ACC = nnz(~isnan(ACC_Area_8));
N_9_ACC = nnz(~isnan(ACC_Area_9));
N_10_ACC = nnz(~isnan(ACC_Area_10));
N_11_ACC = nnz(~isnan(ACC_Area_11));
N_12_ACC = nnz(~isnan(ACC_Area_12));
N_13_ACC = nnz(~isnan(ACC_Area_13));
N_14_ACC = nnz(~isnan(ACC_Area_14));

%Count number of microglia per group
N_MaleC_ACC = N_7_ACC + N_8_ACC;
N_MaleP_ACC = N_9_ACC + N_11_ACC;
N_FemC_ACC = N_13_ACC + N_14_ACC;
N_FemP_ACC = N_10_ACC + N_12_ACC;

Mean_MaleC_ACC = mean(ACC_Area_MaleC,'omitnan');
Mean_FemC_ACC = mean(ACC_Area_FemC,'omitnan');
Std_MaleC_ACC = std(ACC_Area_MaleC,'omitnan');
Std_FemC_ACC = std(ACC_Area_FemC,'omitnan');
Mean_MaleP_ACC = mean(ACC_Area_MaleP,'omitnan');
Mean_FemP_ACC = mean(ACC_Area_FemP,'omitnan');
Std_MaleP_ACC = std(ACC_Area_MaleP,'omitnan');
Std_FemP_ACC = std(ACC_Area_FemP,'omitnan');

%Test baseline sex differences
[H,P,CI,STATS] = ttest2(ACC_Area_MaleC,ACC_Area_FemC,'vartype','unequal')
meanEffectSize(ACC_Area_MaleC,ACC_Area_FemC,Effect="cohen",VarianceType="unequal")

%Test whether male control is different from male paired
[H,P,CI,STATS] = ttest2(ACC_Area_MaleC,ACC_Area_MaleP,'vartype','unequal')
meanEffectSize(ACC_Area_MaleC,ACC_Area_MaleP,Effect="cohen",VarianceType="unequal")

%Test whether female control is different from female paired
[H,P,CI,STATS] = ttest2(ACC_Area_FemC,ACC_Area_FemP,'vartype','unequal')
meanEffectSize(ACC_Area_FemC,ACC_Area_FemP,Effect="cohen",VarianceType="unequal")

%Test whether male paired is different from female paired
[H,P,CI,STATS] = ttest2(ACC_Area_MaleP,ACC_Area_FemP,'vartype','unequal')
meanEffectSize(ACC_Area_MaleP,ACC_Area_FemP,Effect="cohen",VarianceType="unequal")

%Test whether paired are different from unpaired
ACC_Area_AllC = [ACC_Area_7;ACC_Area_8;ACC_Area_13;ACC_Area_14];
ACC_Area_AllP = [ACC_Area_9;ACC_Area_10;ACC_Area_11;ACC_Area_12];
N_AllC_ACC = N_7_ACC+N_8_ACC+N_13_ACC+N_14_ACC;
N_AllP_ACC = N_9_ACC+N_10_ACC+N_11_ACC+N_12_ACC;
Mean_AllC_ACC = mean(ACC_Area_AllC,'omitnan');
Mean_AllP_ACC = mean(ACC_Area_AllP,'omitnan');
Std_AllC_ACC = std(ACC_Area_AllC,'omitnan');
Std_AllP_ACC = std(ACC_Area_AllP,'omitnan');
[H,P,CI,STATS] = ttest2(ACC_Area_AllC,ACC_Area_AllP,'vartype','unequal')
meanEffectSize(ACC_Area_AllC,ACC_Area_AllP,Effect="cohen",VarianceType="unequal")


%%%Anovas

ACC_Area_C = [ACC_Area_7,ACC_Area_8,ACC_Area_13,ACC_Area_14]
[P,ANOVATAB,STATS] = anova1(ACC_Area_C)

ACC_Area_P = [ACC_Area_9,ACC_Area_10,ACC_Area_11,ACC_Area_12];
[P,ANOVATAB,STATS] = anova1(ACC_Area_P)

%2-way in ACC
ACC_Matrix = [ACC_Area_7;ACC_Area_8;ACC_Area_9;ACC_Area_10;ACC_Area_11;ACC_Area_12;ACC_Area_13;ACC_Area_14]
g1 = [Male;Male;Male;Female;Male;Female;Female;Female]
g2 = [UnPaired;UnPaired;Paired;Paired;Paired;Paired;UnPaired;UnPaired]

Female = ones(1279,1)
Male = zeros(1279,1)
[P,T,STATS] = anovan(ACC_Matrix,{g1,g2},'model','interaction')


%2-way in PFC
PFC_Matrix = [PFC_Area_7;PFC_Area_8;PFC_Area_9;PFC_Area_10;PFC_Area_11;PFC_Area_12;PFC_Area_13;PFC_Area_14]
g4 = [Male2;Male2;Male2;Female2;Male2;Female2;Female2;Female2]
g5 = [UnPaired2;UnPaired2;Paired2;Paired2;Paired2;Paired2;UnPaired2;UnPaired2]

Female2 = ones(950,1)
Male2 = zeros(950,1)
[P,T,STATS] = anovan(PFC_Matrix,{g4,g5},'model','interaction')

