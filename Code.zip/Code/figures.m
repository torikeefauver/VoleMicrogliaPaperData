%create bar graph comparing means of data displayed in ACC table


figure(1)
bar1 = [Mean_MaleC_ACC,Mean_FemC_ACC;Mean_MaleC_ACC,Mean_MaleP_ACC;Mean_FemC_ACC,Mean_FemP_ACC;Mean_MaleP_ACC,Mean_FemP_ACC];
bar(bar1)
ylim([0 35])


figure(2)
bar2 = [Mean_MaleC_PFC,Mean_FemC_PFC;Mean_MaleC_PFC,Mean_MaleP_PFC;Mean_FemC_PFC,Mean_FemP_PFC;Mean_MaleP_PFC,Mean_FemP_PFC];
bar(bar2)
ylim([0 35])

figure(3)
bar3 = [Mean_MaleC,Mean_FemC;Mean_MaleC,Mean_MaleP;Mean_FemC,Mean_FemP;Mean_MaleP,Mean_FemP];
bar(bar3) 
ylim([0 35])

%figure(4)
%bar4 = [barACC_Area_7,barPFC_Area_7,Area_7;barACC_Area_8,barPFC_Area_8,Area_8;barACC_Area_9,barPFC_Area_9,Area_9;barACC_Area_11,barPFC_Area_11,Area_11;barACC_Area_10,barPFC_Area_10,Area_10;barACC_Area_12,barPFC_Area_12,Area_12;barACC_Area_13,barPFC_Area_13,Area_13;barACC_Area_14,barPFC_Area_14,Area_14]
%bar(bar4)

%barNaN1 = NaN(950,1);
%barNaN2 = NaN(1279,1);

%barACC_Area_7 = [ACC_Area_7;barNaN1];
%barACC_Area_8 = [ACC_Area_8;barNaN1];
%barACC_Area_9 = [ACC_Area_9;barNaN1];
%barACC_Area_10 = [ACC_Area_10;barNaN1];
%barACC_Area_11 = [ACC_Area_11;barNaN1];
%barACC_Area_12 = [ACC_Area_12;barNaN1];
%barACC_Area_13 = [ACC_Area_13;barNaN1];
%barACC_Area_14 = [ACC_Area_14;barNaN1];

%barPFC_Area_7 = [PFC_Area_7;barNaN2];
%barPFC_Area_8 = [PFC_Area_8;barNaN2];
%barPFC_Area_9 = [PFC_Area_9;barNaN2];
%barPFC_Area_10 = [PFC_Area_10;barNaN2];
%barPFC_Area_11 = [PFC_Area_11;barNaN2];
%barPFC_Area_12 = [PFC_Area_12;barNaN2];
%barPFC_Area_13 = [PFC_Area_13;barNaN2];
%barPFC_Area_14 = [PFC_Area_14;barNaN2];

%figure 5

d7_1 = mean(ACC_Area_7,'omitnan');
d7_2 = mean(PFC_Area_7,'omitnan');
d7_3 = mean(Area_7,'omitnan');
d7means = [d7_1,d7_2,d7_3];

d8_1 = mean(ACC_Area_8,'omitnan');
d8_2 = mean(PFC_Area_8,'omitnan');
d8_3 = mean(Area_8,'omitnan');
d8means = [d8_1,d8_2,d8_3];

d9_1 = mean(ACC_Area_9,'omitnan');
d9_2 = mean(PFC_Area_9,'omitnan');
d9_3 = mean(Area_9,'omitnan');
d9means = [d9_1,d9_2,d9_3];

d11_1 = mean(ACC_Area_11,'omitnan');
d11_2 = mean(PFC_Area_11,'omitnan');
d11_3 = mean(Area_11,'omitnan');
d11means = [d11_1,d11_2,d11_3];

d10_1 = mean(ACC_Area_10,'omitnan');
d10_2 = mean(PFC_Area_10,'omitnan');
d10_3 = mean(Area_10,'omitnan');
d10means = [d10_1,d10_2,d10_3];

d12_1 = mean(ACC_Area_12,'omitnan');
d12_2 = mean(PFC_Area_12,'omitnan');
d12_3 = mean(Area_12,'omitnan');
d12means = [d12_1,d12_2,d12_3];

d13_1 = mean(ACC_Area_13,'omitnan');
d13_2 = mean(PFC_Area_13,'omitnan');
d13_3 = mean(Area_13,'omitnan');
d13means = [d13_1,d13_2,d13_3];

d14_1 = mean(ACC_Area_14,'omitnan');
d14_2 = mean(PFC_Area_14,'omitnan');
d14_3 = mean(Area_14,'omitnan');
d14means = [d14_1,d14_2,d14_3];

figure(5)
bar5 = [d7means;d8means;d9means;d11means;d10means;d12means;d13means;d14means];
bar(bar5) 
ylim([0 35])

figure(6)
bar6 = [Mean_MaleC_ACC,Mean_MaleC_PFC,Mean_MaleC;
    Mean_MaleP_ACC,Mean_MaleP_PFC,Mean_MaleP;
    Mean_FemP_ACC,Mean_FemP_PFC,Mean_FemP;
    Mean_FemC_ACC,Mean_FemC_PFC,Mean_FemC;]
bar(bar6)
ylim([0 35])

%%

figure(7) %ACC ANOVA
scatter1 = [Mean_MaleC_ACC,Mean_FemC_ACC,Mean_MaleP_ACC,Mean_FemP_ACC];
%scatter([1 2 3 4],scatter1,'diamond')
stderrorMCACC = Std_MaleC_ACC ./ sqrt(N_MaleC_ACC);
stderrorFCACC = Std_FemC_ACC ./ sqrt(N_FemC_ACC);
stderrorMPACC = Std_MaleP_ACC ./ sqrt(N_MaleP_ACC);
stderrorFPACC = Std_FemP_ACC ./ sqrt(N_FemP_ACC);
stderror1 = [stderrorMCACC,stderrorFCACC,stderrorMPACC,stderrorFPACC];
ercolor = ['b','r','b','r']
%ershape = ['+','+','diamond','diamond']
hold on
for i = 1:numel(scatter1)
 errorbar(i, scatter1(i), stderror1(i),'.','LineWidth',1,'MarkerFaceColor', ercolor(i), ...
     'MarkerEdgeColor',ercolor(i),'Color',ercolor(i))
end
hold off
%eb1 = errorbar(scatter1,[stderrorMCACC,stderrorFCACC,stderrorMPACC,stderrorFPACC]);
xlim([0 5])
e1 = gca
xticks(e1,[1 2 3 4])
xticklabels(e1,{'Male Unpaired','Female Unpaired','Male Paired','Female Paired'})
%title('Multiple Comparisons: ACC')
ylabel('Somal Area in ACC (square microns)')
hold on
scatter2 = [scatter1(1,1)];
scatter3 = [scatter1(1,2)];
scatter4 = [scatter1(1,3)];
scatter5 = [scatter1(1,4)];
scatter([1],scatter2,10,'bo','MarkerFaceColor','b',LineWidth=2)
scatter([2],scatter3,10,'ro','MarkerFaceColor','r',LineWidth=2)
scatter([3],scatter4,50,'bdiamond','MarkerFaceColor','b',LineWidth=1)
scatter([4],scatter5,50,'rdiamond','MarkerFaceColor','r',LineWidth=1)

%%

figure(10) %ACC Kruskal-Wallis
Median_MaleC_ACC = median(ACC_Area_MaleC,'omitnan');
Median_FemC_ACC = median(ACC_Area_FemC,'omitnan');
Median_MaleP_ACC = median(ACC_Area_MaleP,'omitnan');
Median_FemP_ACC = median(ACC_Area_FemP,'omitnan');
scatter1 = [Median_MaleC_ACC,Median_FemC_ACC,Median_MaleP_ACC,Median_FemP_ACC];
%scatter([1 2 3 4],scatter1,'diamond')
stderrorMCACC = Std_MaleC_ACC ./ sqrt(N_MaleC_ACC);
stderrorFCACC = Std_FemC_ACC ./ sqrt(N_FemC_ACC);
stderrorMPACC = Std_MaleP_ACC ./ sqrt(N_MaleP_ACC);
stderrorFPACC = Std_FemP_ACC ./ sqrt(N_FemP_ACC);
stderror1 = [stderrorMCACC,stderrorFCACC,stderrorMPACC,stderrorFPACC];
ercolor = ['b','r','b','r']
%ershape = ['+','+','diamond','diamond']
hold on
for i = 1:numel(scatter1)
 errorbar(i, scatter1(i), stderror1(i),'.','LineWidth',1,'MarkerFaceColor', ercolor(i), ...
     'MarkerEdgeColor',ercolor(i),'Color',ercolor(i))
end
hold off
%eb1 = errorbar(scatter1,[stderrorMCACC,stderrorFCACC,stderrorMPACC,stderrorFPACC]);
xlim([0 5])
e1 = gca
xticks(e1,[1 2 3 4])
xticklabels(e1,{'Male Unpaired','Female Unpaired','Male Paired','Female Paired'})
%title('Multiple Comparisons: ACC')
ylabel('Somal Area in ACC (square microns)')
hold on
scatter2 = [scatter1(1,1)];
scatter3 = [scatter1(1,2)];
scatter4 = [scatter1(1,3)];
scatter5 = [scatter1(1,4)];
scatter([1],scatter2,10,'bo','MarkerFaceColor','b',LineWidth=2)
scatter([2],scatter3,10,'ro','MarkerFaceColor','r',LineWidth=2)
scatter([3],scatter4,50,'bdiamond','MarkerFaceColor','b',LineWidth=1)
scatter([4],scatter5,50,'rdiamond','MarkerFaceColor','r',LineWidth=1)


%%

figure(8) %PFC ANOVA
scatter1 = [Mean_MaleC_PFC,Mean_FemC_PFC,Mean_MaleP_PFC,Mean_FemP_PFC];
%scatter([1 2 3 4],scatter1,'diamond')
stderrorMCPFC = Std_MaleC_PFC ./ sqrt(N_MaleC_PFC);
stderrorFCPFC = Std_FemC_PFC ./ sqrt(N_FemC_PFC);
stderrorMPPFC = Std_MaleP_PFC ./ sqrt(N_MaleP_PFC);
stderrorFPPFC = Std_FemP_PFC ./ sqrt(N_FemP_PFC);
stderror1 = [stderrorMCPFC,stderrorFCPFC,stderrorMPPFC,stderrorFPPFC];
ercolor = ['b','r','b','r']
%ershape = ['+','+','diamond','diamond']
hold on
for i = 1:numel(scatter1)
 errorbar(i, scatter1(i), stderror1(i),'.','LineWidth',1,'MarkerFaceColor', ercolor(i), ...
     'MarkerEdgeColor',ercolor(i),'Color',ercolor(i))
end
hold off
%eb1 = errorbar(scatter1,[stderrorMCPFC,stderrorFCPFC,stderrorMPPFC,stderrorFPPFC]);
xlim([0 5])
e1 = gca
xticks(e1,[1 2 3 4])
xticklabels(e1,{'Male Unpaired','Female Unpaired','Male Paired','Female Paired'})
%title('Multiple Comparisons: PFC')
ylabel('Somal Area in PFC (square microns)')
hold on
scatter2 = [scatter1(1,1)];
scatter3 = [scatter1(1,2)];
scatter4 = [scatter1(1,3)];
scatter5 = [scatter1(1,4)];
scatter([1],scatter2,10,'bo','MarkerFaceColor','b',LineWidth=2)
scatter([2],scatter3,10,'ro','MarkerFaceColor','r',LineWidth=2)
scatter([3],scatter4,50,'bdiamond','MarkerFaceColor','b',LineWidth=1)
scatter([4],scatter5,50,'rdiamond','MarkerFaceColor','r',LineWidth=1)

%%

figure(11) %PFC Kruskal-Wallis
Median_MaleC_PFC = median(PFC_Area_MaleC,'omitnan');
Median_FemC_PFC = median(PFC_Area_FemC,'omitnan');
Median_MaleP_PFC = median(PFC_Area_MaleP,'omitnan');
Median_FemP_PFC = median(PFC_Area_FemP,'omitnan');
scatter1 = [Median_MaleC_PFC,Median_FemC_PFC,Median_MaleP_PFC,Median_FemP_PFC];
%scatter([1 2 3 4],scatter1,'diamond')
stderrorMCPFC = Std_MaleC_PFC ./ sqrt(N_MaleC_PFC);
stderrorFCPFC = Std_FemC_PFC ./ sqrt(N_FemC_PFC);
stderrorMPPFC = Std_MaleP_PFC ./ sqrt(N_MaleP_PFC);
stderrorFPPFC = Std_FemP_PFC ./ sqrt(N_FemP_PFC);
stderror1 = [stderrorMCPFC,stderrorFCPFC,stderrorMPPFC,stderrorFPPFC];
ercolor = ['b','r','b','r']
%ershape = ['+','+','diamond','diamond']
hold on
for i = 1:numel(scatter1)
 errorbar(i, scatter1(i), stderror1(i),'.','LineWidth',1,'MarkerFaceColor', ercolor(i), ...
     'MarkerEdgeColor',ercolor(i),'Color',ercolor(i))
end
hold off
%eb1 = errorbar(scatter1,[stderrorMCPFC,stderrorFCPFC,stderrorMPPFC,stderrorFPPFC]);
xlim([0 5])
e1 = gca
xticks(e1,[1 2 3 4])
xticklabels(e1,{'Male Unpaired','Female Unpaired','Male Paired','Female Paired'})
%title('Multiple Comparisons: PFC')
ylabel('Somal Area in PFC (square microns)')
hold on
scatter2 = [scatter1(1,1)];
scatter3 = [scatter1(1,2)];
scatter4 = [scatter1(1,3)];
scatter5 = [scatter1(1,4)];
scatter([1],scatter2,10,'bo','MarkerFaceColor','b',LineWidth=2)
scatter([2],scatter3,10,'ro','MarkerFaceColor','r',LineWidth=2)
scatter([3],scatter4,50,'bdiamond','MarkerFaceColor','b',LineWidth=1)
scatter([4],scatter5,50,'rdiamond','MarkerFaceColor','r',LineWidth=1)

%%

figure(9) %Combined Regions ANOVA
scatter1 = [Mean_MaleC,Mean_FemC,Mean_MaleP,Mean_FemP];
%scatter([1 2 3 4],scatter1,'diamond')
stderrorMC = Std_MaleC ./ sqrt(N_MaleC);
stderrorFC = Std_FemC ./ sqrt(N_FemC);
stderrorMP = Std_MaleP ./ sqrt(N_MaleP);
stderrorFP = Std_FemP ./ sqrt(N_FemP);
stderror1 = [stderrorMC,stderrorFC,stderrorMP,stderrorFP];
ercolor = ['b','r','b','r']
%ershape = ['+','+','diamond','diamond']
hold on
for i = 1:numel(scatter1)
 errorbar(i, scatter1(i), stderror1(i),'.','LineWidth',1,'MarkerFaceColor', ercolor(i), ...
     'MarkerEdgeColor',ercolor(i),'Color',ercolor(i))
end
hold off
%eb1 = errorbar(scatter1,[stderrorMC,stderrorFC,stderrorMP,stderrorFP]);
xlim([0 5])
e1 = gca
xticks(e1,[1 2 3 4])
xticklabels(e1,{'Male Unpaired','Female Unpaired','Male Paired','Female Paired'})
%title('Multiple Comparisons: Both')
ylabel('Somal Area in Combined Regions (square microns)')
hold on
scatter2 = [scatter1(1,1)];
scatter3 = [scatter1(1,2)];
scatter4 = [scatter1(1,3)];
scatter5 = [scatter1(1,4)];
scatter([1],scatter2,10,'bo','MarkerFaceColor','b',LineWidth=2)
scatter([2],scatter3,10,'ro','MarkerFaceColor','r',LineWidth=2)
scatter([3],scatter4,50,'bdiamond','MarkerFaceColor','b',LineWidth=1)
scatter([4],scatter5,50,'rdiamond','MarkerFaceColor','r',LineWidth=1)

%%
figure(9) %Combined Regions ANOVA
Median_MaleC = median(Area_MaleC,'omitnan');
Median_FemC = median(Area_FemC,'omitnan');
Median_MaleP = median(Area_MaleP,'omitnan');
Median_FemP = median(Area_FemP,'omitnan');
scatter1 = [Median_MaleC,Median_FemC,Median_MaleP,Median_FemP];
%scatter([1 2 3 4],scatter1,'diamond')
stderrorMC = Std_MaleC ./ sqrt(N_MaleC);
stderrorFC = Std_FemC ./ sqrt(N_FemC);
stderrorMP = Std_MaleP ./ sqrt(N_MaleP);
stderrorFP = Std_FemP ./ sqrt(N_FemP);
stderror1 = [stderrorMC,stderrorFC,stderrorMP,stderrorFP];
ercolor = ['b','r','b','r']
%ershape = ['+','+','diamond','diamond']
hold on
for i = 1:numel(scatter1)
 errorbar(i, scatter1(i), stderror1(i),'.','LineWidth',1,'MarkerFaceColor', ercolor(i), ...
     'MarkerEdgeColor',ercolor(i),'Color',ercolor(i))
end
hold off
%eb1 = errorbar(scatter1,[stderrorMC,stderrorFC,stderrorMP,stderrorFP]);
xlim([0 5])
e1 = gca
xticks(e1,[1 2 3 4])
xticklabels(e1,{'Male Unpaired','Female Unpaired','Male Paired','Female Paired'})
%title('Multiple Comparisons: Both')
ylabel('Somal Area in Combined Regions (square microns)')
hold on
scatter2 = [scatter1(1,1)];
scatter3 = [scatter1(1,2)];
scatter4 = [scatter1(1,3)];
scatter5 = [scatter1(1,4)];
scatter([1],scatter2,10,'bo','MarkerFaceColor','b',LineWidth=2)
scatter([2],scatter3,10,'ro','MarkerFaceColor','r',LineWidth=2)
scatter([3],scatter4,50,'bdiamond','MarkerFaceColor','b',LineWidth=1)
scatter([4],scatter5,50,'rdiamond','MarkerFaceColor','r',LineWidth=1)

%% distributions for combined regions

f1 = figure(1);
%sgtitle(f1,'QQ Plots and Histograms of Somal Area Distributions in ACC and PFC')

s1 = subplot(2,2,1);
p1 = qqplot(Area_MaleC);
p1(3).Color = 'b';
title(s1,'Unpaired Male: Combined ACC & PFC')

s2 = subplot(2,2,2);
p2 = histogram(Area_MaleC);
title(s2,'Unpaired Male: Combined ACC & PFC')
xlabel(s2,'Somal Area (square microns)')
ylabel(s2,'Number of Cells')

s3 = subplot(2,2,3);
p3 = qqplot(Area_MaleP);
p3(3).Color = 'b';
p3(1).Marker = 'diamond'; 
p3(1).MarkerSize = 20;
title(s3,'Paired Male: Combined ACC & PFC')

s4 = subplot(2,2,4);
p4 = histogram(Area_MaleP);
title(s4,'Paired Male: Combined ACC & PFC')
xlabel(s4,'Somal Area (square microns)')
ylabel(s4,'Number of Cells')



f2 = figure(2);

s5 = subplot(2,2,1);
p5 = qqplot(Area_FemC); 
p5(1).MarkerEdgeColor = 'r';
title(s5,'Unpaired Female: Combined ACC & PFC')

s6 = subplot(2,2,2);
p6 = histogram(Area_FemC,FaceColor="r");
title(s6,'Unpaired Female: Combined ACC & PFC')
xlabel(s6,'Somal Area (square microns)')
ylabel(s6,'Number of Cells')

s7 = subplot(2,2,3);
p7 = qqplot(Area_FemP);
p7(1).MarkerEdgeColor = 'r';
p7(1).Marker = 'diamond'; 
p7(1).MarkerSize = 20;
title(s7,'Paired Female: Combined ACC & PFC')

s8 = subplot(2,2,4);
p8 = histogram(Area_FemP,FaceColor="r");
title(s8,'Paired Female: Combined ACC & PFC')
xlabel(s8,'Somal Area (square microns)')
ylabel(s8,'Number of Cells')


%% distributions for ACC

f3 = figure(3);
%sgtitle(f1,'QQ Plots and Histograms of Somal Area Distributions in ACC and PFC')

s1 = subplot(2,2,1);
p1 = qqplot(ACC_Area_MaleC);
p1(3).Color = 'b';
title(s1,'Unpaired Male: ACC')

s2 = subplot(2,2,2);
p2 = histogram(ACC_Area_MaleC);
title(s2,'Unpaired Male: ACC')
xlabel(s2,'Somal Area (square microns)')
ylabel(s2,'Number of Cells')

s3 = subplot(2,2,3);
p3 = qqplot(ACC_Area_MaleP);
p3(3).Color = 'b';
p3(1).Marker = 'diamond'; 
p3(1).MarkerSize = 20;
title(s3,'Paired Male: ACC')

s4 = subplot(2,2,4);
p4 = histogram(ACC_Area_MaleP);
title(s4,'Paired Male: ACC')
xlabel(s4,'Somal Area (square microns)')
ylabel(s4,'Number of Cells')



f4 = figure(4);

s5 = subplot(2,2,1);
p5 = qqplot(ACC_Area_FemC); 
p5(1).MarkerEdgeColor = 'r';
title(s5,'Unpaired Female: ACC')

s6 = subplot(2,2,2);
p6 = histogram(ACC_Area_FemC,FaceColor="r");
title(s6,'Unpaired Female: ACC')
xlabel(s6,'Somal Area (square microns)')
ylabel(s6,'Number of Cells')

s7 = subplot(2,2,3);
p7 = qqplot(ACC_Area_FemP);
p7(1).MarkerEdgeColor = 'r';
p7(1).Marker = 'diamond'; 
p7(1).MarkerSize = 20;
title(s7,'Paired Female: ACC')

s8 = subplot(2,2,4);
p8 = histogram(ACC_Area_FemP,FaceColor="r");
title(s8,'Paired Female: ACC')
xlabel(s8,'Somal Area (square microns)')
ylabel(s8,'Number of Cells')


%% distributions for PFC

f5 = figure(5);
%sgtitle(f1,'QQ Plots and Histograms of Somal Area Distributions in ACC and PFC')

s1 = subplot(2,2,1);
p1 = qqplot(PFC_Area_MaleC);
p1(3).Color = 'b';
title(s1,'Unpaired Male: PFC')

s2 = subplot(2,2,2);
p2 = histogram(PFC_Area_MaleC);
title(s2,'Unpaired Male: PFC')
xlabel(s2,'Somal Area (square microns)')
ylabel(s2,'Number of Cells')

s3 = subplot(2,2,3);
p3 = qqplot(PFC_Area_MaleP);
p3(3).Color = 'b';
p3(1).Marker = 'diamond'; 
p3(1).MarkerSize = 20;
title(s3,'Paired Male: PFC')

s4 = subplot(2,2,4);
p4 = histogram(PFC_Area_MaleP);
title(s4,'Paired Male: PFC')
xlabel(s4,'Somal Area (square microns)')
ylabel(s4,'Number of Cells')



f6 = figure(6);

s5 = subplot(2,2,1);
p5 = qqplot(PFC_Area_FemC); 
p5(1).MarkerEdgeColor = 'r';
title(s5,'Unpaired Female: PFC')

s6 = subplot(2,2,2);
p6 = histogram(PFC_Area_FemC,FaceColor="r");
title(s6,'Unpaired Female: PFC')
xlabel(s6,'Somal Area (square microns)')
ylabel(s6,'Number of Cells')

s7 = subplot(2,2,3);
p7 = qqplot(PFC_Area_FemP);
p7(1).MarkerEdgeColor = 'r';
p7(1).Marker = 'diamond'; 
p7(1).MarkerSize = 20;
title(s7,'Paired Female: PFC')

s8 = subplot(2,2,4);
p8 = histogram(PFC_Area_FemP,FaceColor="r");
title(s8,'Paired Female: PFC')
xlabel(s8,'Somal Area (square microns)')
ylabel(s8,'Number of Cells')