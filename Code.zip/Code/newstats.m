
%% new stats for both regions

[p,h,stats] = ranksum(Area_MaleC,Area_FemC)
effectsize = meanEffectSize(Area_MaleC,Area_FemC,Effect="mediandif")
median1 = median([Area_MaleC,Area_FemC],'omitnan')

[p,h,stats] = ranksum(Area_MaleC,Area_MaleP)
effectsize = meanEffectSize(Area_MaleC,Area_MaleP,Effect="mediandif")
median1 = median([Area_MaleC,Area_MaleP],'omitnan')

[p,h,stats] = ranksum(Area_FemC,Area_FemP)
effectsize = meanEffectSize(Area_FemC,Area_FemP,Effect="mediandif")
median1 = median([Area_FemC,Area_FemP],'omitnan')

[p,h,stats] = ranksum(Area_MaleP,Area_FemP)
effectsize = meanEffectSize(Area_MaleP,Area_FemP,Effect="mediandif")
median1 = median([Area_MaleP,Area_FemP],'omitnan')

[p,h,stats] = ranksum(Area_AllC,Area_AllP)
effectsize = meanEffectSize(Area_AllC,Area_AllP,Effect="mediandif")
median1 = median([Area_AllC,Area_AllP],'omitnan')


%kruskalwallis test both regions
data1 = [Area_MaleC,Area_FemC,Area_MaleP,Area_FemP];
[p,tbl,stats] = kruskalwallis(data1)

%one-way anova both regions
[P,ANOVATAB,STATS] = anova1(data1)

%chi2gof both regions
[h,p,stats] = chi2gof(Area_MaleC)
[h,p,stats] = chi2gof(Area_FemC)
[h,p,stats] = chi2gof(Area_MaleP)
[h,p,stats] = chi2gof(Area_FemP)

%% new stats for ACC

[p,h,stats] = ranksum(ACC_Area_MaleC,ACC_Area_FemC)
effectsize = meanEffectSize(ACC_Area_MaleC,ACC_Area_FemC,Effect="mediandif")
median1 = median([ACC_Area_MaleC,ACC_Area_FemC],'omitnan')

[p,h,stats] = ranksum(ACC_Area_MaleC,ACC_Area_MaleP)
effectsize = meanEffectSize(ACC_Area_MaleC,ACC_Area_MaleP,Effect="mediandif")
median1 = median([ACC_Area_MaleC,ACC_Area_MaleP],'omitnan')

[p,h,stats] = ranksum(ACC_Area_FemC,ACC_Area_FemP)
effectsize = meanEffectSize(ACC_Area_FemC,ACC_Area_FemP,Effect="mediandif")
median1 = median([ACC_Area_FemC,ACC_Area_FemP],'omitnan')

[p,h,stats] = ranksum(ACC_Area_MaleP,ACC_Area_FemP)
effectsize = meanEffectSize(ACC_Area_MaleP,ACC_Area_FemP,Effect="mediandif")
median1 = median([ACC_Area_MaleP,ACC_Area_FemP],'omitnan')

[p,h,stats] = ranksum(ACC_Area_AllC,ACC_Area_AllP)
effectsize = meanEffectSize(ACC_Area_AllC,ACC_Area_AllP,Effect="mediandif")
median1 = median([ACC_Area_AllC,ACC_Area_AllP],'omitnan')

%kruskalwallis test ACC
data2 = [ACC_Area_MaleC,ACC_Area_FemC,ACC_Area_MaleP,ACC_Area_FemP];
[p,tbl,stats] = kruskalwallis(data2);

%one-way anova ACC
[P,ANOVATAB,STATS] = anova1(data2);

%skewness
skewness(data2)

%kurtosis
kurtosis(data2)

%chi2gof both regions
[h,p,stats] = chi2gof(ACC_Area_MaleC)
[h,p,stats] = chi2gof(ACC_Area_FemC)
[h,p,stats] = chi2gof(ACC_Area_MaleP)
[h,p,stats] = chi2gof(ACC_Area_FemP)

%% new stats for PFC

[p,h,stats] = ranksum(PFC_Area_MaleC,PFC_Area_FemC)
effectsize = meanEffectSize(PFC_Area_MaleC,PFC_Area_FemC,Effect="mediandif")
median1 = median([PFC_Area_MaleC,PFC_Area_FemC],'omitnan')

[p,h,stats] = ranksum(PFC_Area_MaleC,PFC_Area_MaleP)
effectsize = meanEffectSize(PFC_Area_MaleC,PFC_Area_MaleP,Effect="mediandif")
median1 = median([PFC_Area_MaleC,PFC_Area_MaleP],'omitnan')

[p,h,stats] = ranksum(PFC_Area_FemC,PFC_Area_FemP)
effectsize = meanEffectSize(PFC_Area_FemC,PFC_Area_FemP,Effect="mediandif")
median1 = median([PFC_Area_FemC,PFC_Area_FemP],'omitnan')

[p,h,stats] = ranksum(PFC_Area_MaleP,PFC_Area_FemP)
effectsize = meanEffectSize(PFC_Area_MaleP,PFC_Area_FemP,Effect="mediandif")
median1 = median([PFC_Area_MaleP,PFC_Area_FemP],'omitnan')

[p,h,stats] = ranksum(PFC_Area_AllC,PFC_Area_AllP)
effectsize = meanEffectSize(PFC_Area_AllC,PFC_Area_AllP,Effect="mediandif")
median1 = median([PFC_Area_AllC,PFC_Area_AllP],'omitnan')



%kruskalwallis test PFC
data3 = [PFC_Area_MaleC,PFC_Area_FemC,PFC_Area_MaleP,PFC_Area_FemP];
[p,tbl,stats] = kruskalwallis(data3);

%one-way anova ACC
[P,ANOVATAB,STATS] = anova1(data3);

%skewness
skewness(data3)

%kurtosis
kurtosis(data3)

%chi2gof both regions
[h,p,stats] = chi2gof(PFC_Area_MaleC)
[h,p,stats] = chi2gof(PFC_Area_FemC)
[h,p,stats] = chi2gof(PFC_Area_MaleP)
[h,p,stats] = chi2gof(PFC_Area_FemP)


